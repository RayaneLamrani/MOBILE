<?php
global $connection;
include './config.php';

if(isset($_POST['Rnummer'])){ 
    $Rnummer = $_POST['Rnummer'];
    $wachtwoord = $_POST['wachtwoord'];

    //$result = $connection->query("SELECT `id`from Users where `Rnummer` = '$Rnummer' and `wachtwoord` = '$wachtwoord'");
    $sql = "SELECT `id`from Users where `Rnummer` = '$Rnummer' and `wachtwoord` = '$wachtwoord'";
    
    if($result = mysqli_query($connection, $sql)) {
        
        $count = mysqli_num_rows($result); 
        //echo "$count";
 
        if($count == 1) {
            session_start();

            $_SESSION['Rnummer']=$Rnummer;

            echo "succes: login succes ";
        }
        else{
            http_response_code(400);
            echo "failed: login failed" ;
        }

    }
    exit;
}
 echo "test";   

?>