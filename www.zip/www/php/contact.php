<?php

global $connection;
include './contact.php';

	if(isset($_POST['verzenden'])){ 
		$naam =$connection->real_escape_string($_POST['naam']);
        $email =$connection->real_escape_string($_POST['email']);
        $comment =$connection->real_escape_string($_POST['bericht']);
		
	
        $data =$connection->query("select 'naam' from vilfoodia_one_sc where 'contact'='$naam'");

		if($data->num_rows > 0){ // als er meer dan 1 record is dan bestaat het account al
			//code voor als het account al Bestaat	
		}
        
        else{ // anders steken we de username en password in de database
            $sql = "INSERT INTO contact (naam,email,bericht) VALUES ('$naam', '$email', '$bericht')";
        
			if ($connection->query($sql) === TRUE) { // als het gelukt is geven we in de console mee 
                exit('{"message": "Bericht verstuurd!", "status" : "success"}'); 
			} else {
                exit('{"message": "Error", "status" : "fail"}');
			}
			
			$connection->close(); // connectie afsluiten
		}			
		}
?>