var myApp = new Framework7();

var $ = Dom7;

var mainView = myApp.addView('.view-main', {
    domCache: true //enable inline pages

});


$(document).on('click', '#registreren', function () {
    var email = $("#email").val();
    var wachtwoord = $("#wachtwoord").val();
    var Rnummer = $("#Rnummer").val()
    if (Rnummer == "" || wachtwoord == "") {

    } else {
        var data = {
            registreren: 1,
            Rnummer: Rnummer,
            email: email,
            wachtwoord: wachtwoord
        };

        $.ajax({
            url: ' http://vilfoodia.one/php/register.php',
            type: "POST",
            data: data,
            success: function (response) {
                $("#login").html(response);
            },

        });
    }
});
$(document).on('click', '#toevoegen', function () {
    var titel = $("#titel").val();
    var jaar = $("#jaar").val();
    var prijs = $("#prijs").val()
    if (titel == "" || jaar == "") {

    } else {
        var data = {
            toevoegen: 1,
            titel: titel,
            jaar: jaar,
            prijs: prijs
        };

        $.ajax({
            url: ' http://vilfoodia.one/php/boeken.php',
            type: "POST",
            data: data,
            success: function (response) {
                $("#response").html(response);
            },
            dataType: 'text',
            crossdomain: true


        });
    }
});

$(document).on('click', '#loginButton', function () {
    var Rnummer = $("#Rnummer1").val();
    var wachtwoord = $("#wachtwoord1").val();
    $.ajax({
        url: ' http://vilfoodia.one/php/login.php',
        type: "POST",
        data: {
            Rnummer: Rnummer,
            wachtwoord: wachtwoord
        },

        dataType: 'JSON',
        success: function (response) {
            //console.log(response);
            //var responseString = JSON.parse(response);
            //console.log(responseString);
            mainView.loadPage("hoofdpagina.html");
        },
        error: function (xhr, status, error) {
            xhr = JSON.stringify(xhr, null, 4);
            console.log("status" + status)

        }
    });
});

$(document).on('keyup', '.searchbar-init input', function() {
    
    const search = this.value;
    
    if(search.length === 0) {
        $('.search-result').css('display', 'none');
        return;
    }
    
    $.ajax({
            url: ' http://vilfoodia.one/php/search.php',
            type: "POST",
            data: { search: search },
            success: function (response) {
                response = JSON.parse(response);
                
                $('.search-result').css('display', 'block').html('');
                
                response.forEach(function(obj) {
                    $(".search-result").append("<h3 class='searchItem'>" + obj.titel + "</h3>");
                });
                
            },
        });
    
});





/*contact*/  