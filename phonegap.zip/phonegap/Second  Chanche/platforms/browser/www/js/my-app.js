
var myApp = new Framework7();

var $$ = Dom7;

var mainView = myApp.addView('.view-main', {
	// Because we use fixed-through navbar we can enable dynamic navbar
	dynamicNavbar: true
});

var mainView = myApp.addView('.view-main', {
    domCache: true //enable inline pages
});


$(document).on('click','#registreren', function () {
        var email = $("#email").val();
        var wachtwoord = $("#wachtwoord").val();
		var Rnummer = $("#Rnummer").val()
        if (Rnummer == "" || wachtwoord == "") {
            //alert("Gelieve uw Rnummer en wachtwoord in te geven!");
        } 
    else {
            var data = { //variabele die we in de php kunnen aanspreken
                registreren: 1,
				Rnummer: Rnummer,
                email: email,
                wachtwoord: wachtwoord
            };

            $.ajax({
                url: 'http://vilfoodia.one/register.php',
                type: "POST",
                data: data,
                success: function (response) {
                    $("#response").html(response);
                },
                dataType: 'text',
                crossdomain: true
                

            });
        }
    });