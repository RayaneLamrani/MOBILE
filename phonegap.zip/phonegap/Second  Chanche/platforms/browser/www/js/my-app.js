
var myApp = new Framework7();

var $$ = Dom7;

var mainView = myApp.addView('.view-main', {
	// Because we use fixed-through navbar we can enable dynamic navbar
	dynamicNavbar: true
});

var mainView = myApp.addView('.view-main', {
    domCache: true //enable inline pages
});


var form = document.getElementById("form-id");

document.getElementById("your-id").addEventListener("click", function () {
  form.submit();
});