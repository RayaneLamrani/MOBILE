<?php
      
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

	if(isset($_POST['toevoegen'])){ 
		$connection = mysqli_connect('vilfoodia.one.mysql', 'vilfoodia_one_sc', '3htb16', 'vilfoodia_one_sc') or die(mysqli_connect_error()); // connectie met de database
		
		
		$titel = $connection->real_escape_string($_POST['titel']);
		$jaar = $connection->real_escape_string($_POST['jaar']); 
		$prijs = ($connection->real_escape_string($_POST['prijs']));
		
	
		$data = $connection->query("select titel from vilfoodia_one_sc where boeken = '$titel'");

		if($data->num_rows > 0){ // als er meer dan 1 record is dan bestaat het account al
			//code voor als het account al Bestaat	
		}
        
        else{ // anders steken we de username en password in de database
			$sql = "INSERT INTO boeken (titel,jaar,prijs) VALUES ('$titel', '$jaar', '$prijs')";
			if ($connection->query($sql) === TRUE) { // als het gelukt is geven we in de console mee 
                exit('{"message": "login success", "status" : "success"}'); 
			} else {
                exit('{"message": "login failed", "status" : "fail"}');
			}
			
			$connection->close(); // connectie afsluiten
		}			
		}
    ?>