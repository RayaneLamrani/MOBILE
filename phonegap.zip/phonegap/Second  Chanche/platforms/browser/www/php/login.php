<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if(isset($_POST['login'])){ 
    $connection = mysqli_connect('vilfoodia.one.mysql', 'vilfoodia_one_sc', '3htb16', 'vilfoodia_one_sc') or die(mysqli_connect_error()); // connectie met de database

    $Rnummer= $_POST['Rnummer'];
    $wachtwoord = $_POST['wachtwoord'];


    $result = $connection->query("SELECT `id`from Users where `Rnummer` = '$Rnummer' and `wachtwoord` = '$wachtwoord'");



if($result->num_rows > 0) {
    session_start();

    $_SESSION['Rnummer']=$Rnummer;
    
    echo "succes: login succes ";
}
    else{
        
    echo "failed: login failed" ;
}
    
}
    

?>