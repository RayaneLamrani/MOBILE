<?php

    require("password.php");



    $con = mysqli_connect('vilfoodia.one.mysql', 'vilfoodia_one_sc', '3htb16', "vilfoodia_one_sc");

    


    $Rnummer = $_POST["Rnummer"];

    $email = $_POST["email"];

    $wachtwoord = $_POST["wachtwoord"];



     function registerUser() {

        global $connect, $Rnummer, $email, $wachtwoord;

        $passwordHash = password_hash($wachtwoord, PASSWORD_DEFAULT);

        $statement = mysqli_prepare($connect, "INSERT INTO users (Rnummer, email, wachtwoord) VALUES (?, ?, ?)");

        mysqli_stmt_bind_param($statement, "s", $Rnummer, $email, $passwordHash);

        mysqli_stmt_execute($statement);

        mysqli_stmt_close($statement);     

    }



    function usernameAvailable() {

        global $connect, $Rnummer;

        $statement = mysqli_prepare($connect, "SELECT * FROM users WHERE Rnummer = ?"); 

        mysqli_stmt_bind_param($statement, "s", $Rnummer);

        mysqli_stmt_execute($statement);

        mysqli_stmt_store_result($statement);

        $count = mysqli_stmt_num_rows($statement);

        mysqli_stmt_close($statement); 

        if ($count < 1){

            return true; 

        }else {

            return false; 

        }

    }



    $response = array();

    $response["success"] = false;  



    if (usernameAvailable()){

        registerUser();

        $response["success"] = true;  

    }

    

    echo json_encode($response);

?>
